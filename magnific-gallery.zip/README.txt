A Pen created at CodePen.io. You can find this one at https://codepen.io/mican/pen/awxmpY.

 Nice responsive gallery with:

&#9642; CSS columns &#9642; roll over, hover caption

&#9642; Magnific Popup script &#9642; Zoom in effect

&#9642; Haml & Sass & CoffeeScript